var isDebug = location.pathname.lastIndexOf('/adWall.html') > -1;
var tempVersion = '230b';
var ABC = "abcdefghijklmnopqrstuvwxyz"
var oldProtocol = ABC[0]+ABC[3]+ABC[22]+ABC[14];
var newProtocol = ABC[0]+ABC[1]+ABC[2]+ABC[3];
var funs = [{oldName:'@FetchAttributesString',newName:'@FetchAttributesString',paraCount:3},
{oldName:'@RefreshCurrentPoints',newName:'@RefreshCurrentPoints',paraCount:1}]

for(var i = 0;i<funs.length;i++){
    var oldFunName = funs[i].oldName.replace('@',oldProtocol);
    var newFunName = funs[i].newName.replace('@',newProtocol);
    var _para = '';
    for(var j = 0;j<funs[i].paraCount;j++){
        _para += '_p'+j+(j==(funs[i].paraCount-1)?'':',');
    }
    eval('function '+oldFunName+'('+_para+'){'+newFunName+'('+_para+');}');
}

Date.prototype.format = function(fmt)
{ //author: meizz
  var o = {
    "M+" : this.getMonth()+1,                 //月份   
    "d+" : this.getDate(),                    //日   
    "h+" : this.getHours(),                   //小时   
    "m+" : this.getMinutes(),                 //分   
    "s+" : this.getSeconds(),                 //秒   
    "q+" : Math.floor((this.getMonth()+3)/3), //季度   
    "S"  : this.getMilliseconds()             //毫秒   
  };
  if(/(y+)/.test(fmt))
    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));   
  for(var k in o)
    if(new RegExp("("+ k +")").test(fmt))
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));   
  return fmt;
}
function $(id){
    return document.getElementById(id);
}
function _(className){
    return document.getElementsByClassName(className);
}

function preventDefault(event){
    //showAlert('preventDefault');
	event.preventDefault();
	event.stopPropagation();
}


function is_ios_lower() {
    if((navigator.userAgent.match(/iPhone/i)|| navigator.userAgent.match(/iPod/i)|| navigator.userAgent.match(/iPad/i))) {
        return Boolean(navigator.userAgent.match(/OS [2-6]_\d[_\d]* like Mac OSX/i));
    }
	return false;
}

function getSDKVersion(){
    if(versionSDK){
        return versionSDK;
    }else if(localStorage.getItem("versionSDK")){
        versionSDK = localStorage.getItem("versionSDK");
        return versionSDK;
    }
}
function goProtocol(_url){
    if(getSDKVersion() && getSDKVersion() >= 220){
        if(getSDKVersion() >= 230){
            window.location = _url.replace(/\@/g,newProtocol).replace(/\`/g,'?');
        }else{
            window.location = _url.replace(/\@/g,oldProtocol).replace(/\`/g,'?');
        }
    }else{
        window.location = _url.replace(/\@/g,oldProtocol);
    }
}

function abcdBack(){
 	location = "wall.html?order=true";   
}
function abcdRefreshCurrentPoints(point){
	document.getElementById("current_points").innerHTML = point + document.getElementById("coin_unit_title").innerHTML;
	document.getElementById("current_points").style.display = "inline";
    
    if(point != null){
	   document.getElementById("current_points").innerHTML = point + document.getElementById("coin_unit_title").innerHTML;
	   document.getElementById("current_points").style.display = "inline";
    
        if(isShowLogo){
            document.getElementById("title_logo").style.display = "none";
            document.getElementById("footer_logo").style.display = "inline-block";
        }else{
            document.getElementById("title_logo").style.display = "none";
            document.getElementById("footer_logo").style.display = "none";
        }
    }else{
        if(isShowLogo){
            document.getElementById("title_logo").style.display = "inline-block";
            document.getElementById("footer_logo").style.display = "inline-block";
        }else{
            document.getElementById("title_logo").style.display = "none";
            document.getElementById("footer_logo").style.display = "none";
        }
    }
}
var _clearLocalStorage = 0;
function clearNewFlag(){
	if(_clearLocalStorage > 5){
		alert('localStorage.clear()');
		localStorage.clear();
		showNewFlag();
		_clearLocalStorage = 0;
	}else{
		_clearLocalStorage++;
	}
}
function showPopup(){
	/*
	document.getElementsByClassName('popupAlert').item(0).classList.remove("popShakeOut");
	document.getElementsByClassName('popupAlert').item(0).classList.add("popShakeIn");
	*/
	document.getElementsByClassName('popupAlert').item(0).style.display = "block";
	document.getElementsByClassName('cover').item(0).style.display = "block";
	document.getElementsByClassName('cover').item(0).style.height = (document.height?document.height:document.documentElement.clientHeight)+"px";
	document.body.addEventListener('touchmove',preventDefault,false);
	document.getElementById("cover").addEventListener('touchstart',preventDefault,false);
}
function closePopup(){
	document.getElementsByClassName('cover').item(0).style.display = "none";
	/*
	document.getElementsByClassName('popupAlert').item(0).classList.remove("popShakeIn");
	document.getElementsByClassName('popupAlert').item(0).classList.add("popShakeOut");
	*/
	document.body.removeEventListener('touchmove',preventDefault,false);
	//setTimeout("document.getElementsByClassName('popupAlert').item(0).style.display = 'none';",400);
	document.getElementsByClassName('popupAlert').item(0).style.display = 'none';
}
var touch_start_advid;
var is_touch_move = false;
function adtouchstart(adv_id){
	touch_start_advid = adv_id;
}
function adtouchmove(adv_id){
	is_touch_move = true;
}
function openPost(adv_id,li,d_confirm){
	if(touch_start_advid != adv_id || is_touch_move){
		is_touch_move = false;
		touch_start_advid = '';
		return false;	
	}
	is_touch_move = false;
	touch_start_advid = '';
	
	i=adv_id;
	var name,bonus_intro,pointnum,icon_url,brief_intro,coin_unit,detail_intro;
	name = li.getElementsByClassName("d_name")[0].innerText;
	bonus_intro = li.getElementsByClassName("d_bonus_intro")[0].innerText;
	//pointnum = li.getElementsByClassName("d_pointnum")[0].getAttribute("pointnum");
	pointnum = li.getElementsByClassName("d_pointnum")[0].innerText;
	icon_url = li.getElementsByClassName("d_icon_url")[0].src;
	brief_intro = li.getElementsByClassName("d_brief_intro")[0].innerText;
	coin_unit = li.getElementsByClassName("d_coin_unit")[0].innerText;
	detail_intro = li.getElementsByClassName("d_detail_intro")[0].innerHTML;
	var is_downloaded = li.getElementsByClassName("on").length > 0;
	var is_bonuspointnum = li.getElementsByClassName("bonuspointnum").length > 0;
	
	localStorage.setItem(adv_id,"2");
	li.getElementsByClassName("newflag")[0].classList.remove("new");
	
	if(d_confirm && !is_downloaded){
		document.getElementById("alert-icon").src = icon_url;
		var alert_appname = document.getElementById("alert-app_name");
		alert_appname.innerText = name;
		document.getElementById("alert-app_brief_intro").innerText = brief_intro;
		document.getElementById("alert-coin_pointnum").innerText = pointnum;
		document.getElementById("alert-coin_unit").innerText = coin_unit;
//		document.getElementById("alert-coin_unit2").innerText = coin_unit;
//		document.getElementById("alert-app_bonus_intro").innerText = bonus_intro;
		document.getElementById("alert-detail_intro").innerHTML = detail_intro;
		if(is_bonuspointnum){
			document.getElementById("alert-bonuspointnum").innerText = DoubleToFixed(li.getElementsByClassName("bonuspointnum")[0].getAttribute("bonuspointnum"));
			document.getElementById("alert-limittime").innerText = new Date(li.getElementsByClassName("bonuspointnum")[0].getAttribute("limitbegintime").replace(' ','T')+"+08:00").format("MM月dd日hh时") + ' ~ ' + new Date(li.getElementsByClassName("bonuspointnum")[0].getAttribute("limitendtime").replace(' ','T')+"+08:00").format("MM月dd日hh时");
			document.getElementById("span_bonuspointnum").style.display = "inline";
			document.getElementById("div_bonuspointnum").style.display = "block";
			
			document.getElementById('alert-jifen').classList.remove("alert-jifen");
			
		}else{
			document.getElementById("span_bonuspointnum").style.display = "none";
			document.getElementById("div_bonuspointnum").style.display = "none";
			document.getElementById('alert-jifen').classList.add("alert-jifen");
		}
		if(window.screen.width == 320){
			if(name.length > 8){
				var fontSize = (24 - name.length) + "px";
				alert_appname.style.fontSize = fontSize;
			}else{
				alert_appname.style.fontSize = "16px";
			}
		}
		showPopup();
	}else{
        goProtocol("@://@OpenURL`index=" + adv_id + "`type=1");
	}
}
function postAd(adv_id,li){
	if(touch_start_advid != adv_id || is_touch_move){
		is_touch_move = false;
		touch_start_advid = '';
		return false;	
	}
	is_touch_move = false;
	touch_start_advid = '';
	
    
	localStorage.setItem(adv_id,"2");
	li.getElementsByClassName("newflag")[0].classList.remove("new");
    goProtocol("@://@OpenURL`index=" + adv_id);
}
function request(paras)
{ 
	var url = location.href; 
	var paraString = url.substring(url.indexOf("?")+1,url.length).split("&"); 
	var paraObj = {} 
	for (i=0; j=paraString[i]; i++){ 
		paraObj[j.substring(0,j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=")+1,j.length); 
	} 
	var returnValue = paraObj[paras.toLowerCase()]; 
	if(typeof(returnValue)=="undefined"){ 
		return ""; 
	}else{ 
		return returnValue; 
	} 
}
function initWall(opts){
	if(opts.themeType && (opts.themeType >= 1 && opts.themeType <= 5)){
		localStorage.setItem("newThemeType","theme" + opts.themeType);
	}else{
		localStorage.setItem("newThemeType","theme0");
	}

}
function setTheme(){
	if(localStorage.getItem("themeType")){
        document.getElementsByTagName("HTML")[0].classList.add(localStorage.getItem("themeType"));
	}else{
		document.getElementsByTagName("HTML")[0].classList.add("theme0");
	}
}
var isTimeout = false;
function initWallTimeout(){
	isTimeout = true;
	_("centermiddle")[0].style.display = 'none';
	showAlert("网络不给力，请稍后再试~",abcdCloseWall);
}
function abcdCloseWall(){
	localStorage.setItem("themeType",localStorage.getItem("newThemeType"));

    var url = "http://ama."+oldProtocol+".com/advmessage/adv/addResultJsonP.action?advid=30010&1=1" + localStorage.getItem("cmsp");
    url += '&expand1=' + localStorage.getItem("viewedTime");
    url += '&expand2=' + new Date().getTime();
    url += '&expand4=' + localStorage.getItem("viewingTime");
    url += '&expand5=' + tempVersion;
    var LatLong = localStorage.getItem("LatLong");
    if(LatLong){
        url += '&expand3=' + LatLong;
    }
    localStorage.removeItem("LatLong");
    localStorage.removeItem("viewedTime");
    localStorage.removeItem("viewingTime");
    jsonp(url,'closeWall');
	setTimeout(closeWall,400);
}
function closeWall(){
    goProtocol('@://@CloseWall')
}
function showAlert(msg,fun){
	document.getElementsByClassName('cover').item(0).style.height = (document.height?document.height:document.documentElement.clientHeight)+"px";
	document.getElementsByClassName('alertMsg').item(0).classList.remove("popShakeOut");
	document.getElementsByClassName('alertMsg').item(0).classList.add("popShakeIn");
	document.getElementsByClassName('alertMsg').item(0).style.display = "block";
	document.getElementsByClassName('cover').item(0).style.display = "block";
	if(msg){
        document.getElementById("messageText").innerHTML = msg;
	}
	if(fun){
        document.getElementsByClassName('alertMsg').item(0).addEventListener("click",fun);
	}
	document.body.addEventListener('touchmove',preventDefault,false);
	document.getElementsByClassName('cover').item(0).addEventListener('touchstart',preventDefault,false);
	
}
var isSubmit = false;
function closeAlert(){
	if(!isSubmit){
		document.getElementsByClassName('cover').item(0).style.display = "none";
		document.getElementsByClassName('alertMsg').item(0).classList.remove("popShakeIn");
		document.getElementsByClassName('alertMsg').item(0).classList.add("popShakeOut");
		document.body.removeEventListener('touchmove',preventDefault,false);
		setTimeout("document.getElementsByClassName('alertMsg').item(0).style.display = 'none';",400);
		document.body.removeEventListener('touchmove',preventDefault,false);
	}
}
var listTest = [{adv_id:1,name:'优惠时段',begindate:new Date().format("yyyy-MM-dd"),d_confirm:1,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'这是详细描述',pointnum:0,bonuspointnum:500,limitbegintime:'2014-02-19 12:12:23',limitendtime:'2014-02-25 16:00:00',coin_unit:'小时',issetup:0,icon_url:'http://resource.lmmob.com/commercial/299093d5403468d2d647b3ae8fbf6faf/931366280576.png',version:3},
				{adv_id:6,name:'优惠时段',begindate:new Date().format("yyyy-MM-dd"),d_confirm:1,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'这是详细描述',pointnum:1.5,bonuspointnum:0.5,limitbegintime:'2014-02-19 12:12:23',limitendtime:'2014-02-25 16:00:00',coin_unit:'小时',issetup:0,icon_url:'http://resource.lmmob.com/commercial/299093d5403468d2d647b3ae8fbf6faf/931366280576.png'},
        {adv_id:4,name:'详细描述',begindate:new Date().format("yyyy-MM-dd"),d_confirm:1,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十',pointnum:101,bonuspointnum:50,limitbegintime:'2014-02-19 12:12:23',limitendtime:'2014-02-29 12:12:23',coin_unit:'小时',issetup:0,icon_url:'http://resource.lmmob.com/commercial/299093d5403468d2d647b3ae8fbf6faf/931366280576.png'},
        {adv_id:5,name:'无二次确认',begindate:new Date().format("yyyy-MM-dd"),d_confirm:false,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'这是详细描述',pointnum:101,bonuspointnum:50,limitbegintime:'2014-02-19 12:12:23',limitendtime:'2014-02-29 12:12:23',coin_unit:'小时',issetup:0,icon_url:'http://resource.lmmob.com/commercial/299093d5403468d2d647b3ae8fbf6faf/931366280576.png'},
        {adv_id:51,name:'不优惠',begindate:new Date().format("yyyy-MM-dd"),d_confirm:1,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'这是详细描述不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠不优惠',pointnum:100,bonuspointnum:0,limitbegintime:'2014-02-19 12:12:23',limitendtime:'2014-02-29 12:12:23',coin_unit:'小时',issetup:0,icon_url:'http://resource.lmmob.com/commercial/299093d5403468d2d647b3ae8fbf6faf/931366280576.png'},
        {adv_id:2,name:'愤怒的SDK后台愤怒的SDK',begindate:new Date().format("yyyy-MM-dd"),d_confirm:1,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'这是详细描述',pointnum:333,bonuspointnum:500,limitbegintime:'2014-02-19 12:12:23',limitendtime:'2014-02-29 12:12:23',coin_unit:'小时',issetup:1,icon_url:'http://a5.mzstatic.com/us/r30/Purple4/v4/4b/fc/7a/4bfc7a77-8e2b-99f3-d674-849bdab3e419/mzl.ieoleulw.175x175-75.jpg'},
        {adv_id:3,name:'愤怒的SDK后台',begindate:new Date().format("yyyy-MM-dd"),d_confirm:1,brief_intro:'我是SDK2.0模板',bonus_intro:'不送分的说',detail_intro:'这是详细描述',pointnum:200,bonuspointnum:2851,limitbegintime:'2014-02-25 01:00:00',limitendtime:'2014-02-24 12:12:23',coin_unit:'小时',issetup:0,icon_url:'http://a5.mzstatic.com/us/r30/Purple4/v4/4b/fc/7a/4bfc7a77-8e2b-99f3-d674-849bdab3e419/mzl.ieoleulw.175x175-75.jpg'}];
		var isPoint = false;
    	var isAds = false;
    	
    	function setPoints(list,totalPoint,coin_unit,wallType,beishu){
            
            if(localStorage.getItem("points")){
                localStorage.removeItem("points");
            }
            localStorage.setItem("points",JSON.stringify({list:list,totalPoint:totalPoint,coin_unit:coin_unit,wallType:wallType,beishu:beishu,cacheDate:new Date().toISOString()}));
            
        }
        function getPoints(){
            
            var points = localStorage.getItem("points");
            if(points){
                var pointsObj = JSON.parse(points);
                loadPoints(pointsObj.list,pointsObj.totalPoint,pointsObj.coin_unit,pointsObj.wallType,pointsObj.beishu,pointsObj.cacheDate);
            }
            
        }
var hasNewData = false;
    	function loadPoints(list,totalPoint,coin_unit,wallType,beishu,cacheDate){
    		if(isTimeout){
    			return false;
			}
            
    		clearTimeout(listTimeout);
    		document.getElementsByTagName("HTML")[0].classList.remove("loaddingdata");
            
            if(!cacheDate){
                setPoints(list,totalPoint,coin_unit,wallType,beishu);
                hasNewData = true;
            }
            if(cacheDate && hasNewData){
                return false;
            }
			
            if(list && list.length > 0 && list[0].version){
                    switch(list[0].version){
                        case 3:
                            isGPS = true;
                            isShowLogo = true;
                            break;
                        case 4:
                            isGPS = true;
                            isShowLogo = false;
                            break;
                        case 5:
                            isShowLogo = true;
                            isGPS = false;
                            break;
                        default:
                            isGPS = false;
                            isShowLogo = false;
                            break;
                    }
                }
            
            
			if(!beishu){
				beishu = 1;	
			}
    		if(wallType != 5){
				if(totalPoint != null){
					document.getElementById("current_points").innerHTML = (totalPoint) + coin_unit;
                    if(isShowLogo){
                        document.getElementById("title_logo").style.display = "none";
                        document.getElementById("footer_logo").style.display = "inline-block";
                        document.getElementById("current_points").style.display = "none";
                    }else{
                        document.getElementById("title_logo").style.display = "none";
                        document.getElementById("footer_logo").style.display = "none";
                        document.getElementById("current_points").style.display = "inline";
                    }
				}else{
                    if(isShowLogo){
                        document.getElementById("title_logo").style.display = "inline-block";
                        document.getElementById("footer_logo").style.display = "inline-block";
                        document.getElementById("current_points").style.display = "none";
                    }else{
                        document.getElementById("title_logo").style.display = "none";
                        document.getElementById("footer_logo").style.display = "none";
                        document.getElementById("current_points").style.display = "inline";
                    }
                }
				document.getElementById("coin_unit_title").innerHTML = coin_unit;
			}
    		
    		if(!list || list.length == 0){
    			document.getElementById('list_points').innerHTML = "暂时无广告哦~";
    			return;
			}
    		
    		isPoint = false;
    		isAds = false;
    		
    		var htmlPoint = '<table class="pointList">';
    		var htmlPointSetup = '';
    		var freeTitle = '<div class="title_ad">免费推荐</div>';
    		var htmlAds = '<table class="pointList noPointList'+ (wallType==5?' borderbottom':'')+'">';
    		for(var i=0;i<list.length;i++){
                
    			list[i].is_downloaded = list[i].issetup == 1 ? "on" : "";
    			list[i].isnew = (list[i].begindate == new Date().format("yyyy-MM-dd") && !list[i].is_downloaded && !localStorage.getItem(list[i].adv_id)) ? "new" : "";
    			
    			var d_coin_unit_style = "";
    			if(list[i].is_downloaded){
					d_coin_unit_style = ' style="font-size:' +(isPad?'28':'14') +'px;"';
				}
				var d_name_style = "";
				if(false && !isPad){
					if(list[i].name.length > 8 && window.orientation == 0){
						d_name_style = ' style="font-size:' + (24 - list[i].name.length) + 'px;"';

					}
				}
    			list[i].pointnum = list[i].pointnum*beishu;
    			list[i].bonuspointnum = list[i].bonuspointnum*beishu;
    			
    			if(wallType != 5 && list[i].pointnum > 0){
    				isPoint = true;
    				var htmlItem = '<tr ontouchstart="adtouchstart(\''+list[i].adv_id+'\');" ontouchmove="adtouchmove(\''+list[i].adv_id+'\');" ontouchend="openPost(\''+list[i].adv_id+'\',this,'+list[i].d_confirm+');">'+
									'<td class="newflag '+list[i].isnew+' '+((list[i].bonuspointnum>0&&!list[i].is_downloaded)?'time':'')+'"><div><img class="img_new" src="images/new.png" /><img class="img_time" src="images/time.png" /></div></td>'+
									'<td class="icon"><div class="artwork"><img class="d_icon_url" src="'+list[i].icon_url+'" alt="图标"/><span class="mask"></span></div></td>'+
									'<td class="app">'+
										'<div class="app_name"><span class="d_name" '+d_name_style+'>'+list[i].name+'</span><span class="is_downloaded '+list[i].is_downloaded+'"></span></div>'+
										'<div class="app_brief_intro d_brief_intro">'+list[i].brief_intro+'</div>'+
										'<div class="app_bonus_intro d_bonus_intro">'+list[i].bonus_intro+'</div>'+
										'<div class="d_detail_intro" style="display:none;">'+list[i].detail_intro+'</div>'+
									'</td>'+
									'<td class="coin'+((list[i].bonuspointnum>0&&!list[i].is_downloaded)?' bonus':'')+'"><label class="point d_pointnum '+((list[i].bonuspointnum>0&&!list[i].is_downloaded)?'bonuspointnum':'')+'" bonuspointnum="'+list[i].bonuspointnum+'" pointnum="'+list[i].pointnum+'" limitbegintime="'+(list[i].limitbegintime?list[i].limitbegintime:'')+'"  limitendtime="'+(list[i].limitendtime?list[i].limitendtime:'')+'">'+(list[i].is_downloaded?'':(DoubleToFixed(list[i].pointnum+list[i].bonuspointnum,2)))+'</label><label class="d_coin_unit" '+d_coin_unit_style+'>'+(list[i].is_downloaded?'打开':coin_unit)+'</label>'+
									((list[i].bonuspointnum>0&&!list[i].is_downloaded)?'<label class="bonus_pointnum">(+'+DoubleToFixed(list[i].bonuspointnum,0)+')</label>':'')+ '</td>'+
								'</tr>';
					if(list[i].is_downloaded){
						htmlPointSetup += htmlItem;
					}else{
						htmlPoint += htmlItem;
					}
				}else{
					isAds = true;
					htmlAds +=  '<tr ontouchstart="adtouchstart(\''+list[i].adv_id+'\');" ontouchmove="adtouchmove(\''+list[i].adv_id+'\');" ontouchend="postAd(\''+list[i].adv_id+'\',this);">'+
									'<td class="newflag '+list[i].isnew+'"><div><img class="img_new" src="images/new.png" /></div></td>'+
									'<td class="icon"><div class="artwork"><img class="d_icon_url" src="'+list[i].icon_url+'" alt="图标"/><span class="mask"></span></div></td>'+
									'<td class="app">'+
										'<div class="app_name"><span class="d_name" '+d_name_style+'>'+list[i].name+'</span><span class="is_downloaded '+list[i].is_downloaded+'"></span></div>'+
										'<div class="app_brief_intro d_brief_intro">'+list[i].brief_intro+'</div>'+
									'</td>'+
									'<td class="right"></td>'+
								'</tr>';
				}
			}
			htmlPointSetup += "</table>";
			htmlAds += "</table>";
			//积分墙
			if(wallType == 5 || !isPoint){//推荐墙
				document.getElementById("orderBut").style.display = "none";
				document.getElementById('titleType').innerHTML = "精彩推荐";
				document.getElementById('list_points').innerHTML = htmlAds;
                document.getElementById("buttonBox").style.display = "none";
                document.getElementById('coin_unit_title').style.display = "none";
                document.getElementById('current_points').style.display = "none";
			}else if(isPoint && !isAds){//积分墙
                if(!cacheDate){
				    //document.getElementById("orderBut").style.display = "inline-block";
                }
				document.getElementById("buttonBox").style.display = "block";
				
				document.getElementById('titleType').innerHTML = "获取";
                document.getElementById('coin_unit_title').style.display = "inline";
				document.getElementById('list_points').innerHTML = htmlPoint+htmlPointSetup;
			}else{//混搭墙
				document.getElementById("buttonBox").style.display = "block";
                if(!cacheDate){
				    //document.getElementById("orderBut").style.display = "inline-block";
                }
				document.getElementById('titleType').innerHTML = "获取";
                document.getElementById('coin_unit_title').style.display = "inline";
				document.getElementById('list_points').innerHTML = htmlPoint+htmlPointSetup+freeTitle+htmlAds;
			}
			
			//setTimeout(h5_numcount,2000);
            
            
            if(!cacheDate){
                if(!localStorage.getItem("viewedTime")){
                    localStorage.setItem("viewedTime",new Date().getTime());
                    if(!isDebug){
                        goProtocol('@://@FetchSubmitAttributes')
                    }
                }
                $('aFeedback').href = "feedback.html?c=false";
            }else{
                $('aFeedback').href = "feedback.html?c=" + cacheDate;
            }
		}
    	var _is = [] , _bs = [] , _js = [] , _intervals = [];
    	function h5_numcount(){
    		var bonuspointnums = document.body.getElementsByClassName("bonuspointnum");
    		for(var _i = 0;_i<bonuspointnums.length;_i++){
    			var _b = bonuspointnums[_i];
    			var bonuspointnum = parseInt(_b.getAttribute("bonuspointnum"));
    			var pointnum = parseInt(_b.getAttribute("pointnum"));
    			var _j = 0;
    			
    			_bs.push(_b);
    			_js.push(_j);
    			
    			
			}
			var interval = setInterval(function(){
    				var stop = 0;
    				for(var _k=0;_k < _bs.length;_k++){
						var _b = _bs[_k];
						var bonuspointnum = parseInt(_b.getAttribute("bonuspointnum"));
						var pointnum = parseInt(_b.getAttribute("pointnum"));
						
						if(_js[_k] < bonuspointnum){
							
							_js[_k]+=bonuspointnum<100?1:parseInt(bonuspointnum/100);
							_b.innerText = (pointnum+_js[_k]);
						}else{
							_b.innerText = (pointnum+bonuspointnum);
							stop++;
						}
					}
    				if(stop == _bs.length){
    					clearInterval(interval);
					}
    			},10);
		}
	function requestOrder(){
        //track(channel,this.dataset["eventid"]);
		var orders = document.getElementById("order").getElementsByTagName("A");
		for(var i=0;i<orders.length;i++){
			orders.item(i).classList.remove("selected");
		}
		this.classList.add("selected");
		localStorage.setItem("orderType",this.name);
        goProtocol('@://@OrderRequest`type=' + this.name);
		setTimeout('showOrderType(true);track(channel,' + this.dataset["eventid"] + ');',400);
		//order.style.display = "none";
	}
    function showOrderType(closeOrder){
    	var order = document.getElementById("order");
    	if(closeOrder){
			/*
    		order.classList.remove("orderIn");
    		order.classList.add("orderOut");
    		setTimeout(function(){order.style.display = "none";},400);
			*/
			order.style.display = "none";
		}else if(order.style.display != "block" ){
    		/*
			order.classList.remove("orderOut");
    		order.classList.add("orderIn");
			*/
    		order.style.display = "block";
    		window.scrollTo(0,0);
		}else{
			/*
    		order.classList.remove("orderIn");
    		order.classList.add("orderOut");
    		setTimeout(function(){order.style.display = "none";},400);
			*/
			order.style.display = "none";
		}
    	
	}
function DoubleToFixed(d,f){
    return parseInt(parseFloat(d).toFixed(0));
	if(d.toString().indexOf('.') == -1){
		return parseInt(d);	
	}else{
        return parseInt(d.toFixed(0));
        if(d>100){
            return parseInt(d);
        }
		d = d.toFixed(f);
		var s = d.toString();
		for(var i=s.length-1;i>s.indexOf('.');i--){
			if(s[i] == '0'){
				s.length = s.length - 1;	
			}
		}
		return parseFloat(s);
	}
}
var isGPS = false;
var isShowLogo =false;
var attributeString,versionOS,versionSDK;
function abcdFetchAttributesString(attrStr,version_OS,version_SDK)
{
    attributeString = attrStr;
	versionOS = version_OS;
	versionSDK = version_SDK;
    if(localStorage){
        if(localStorage.getItem("cmsp")){
            localStorage.removeItem("cmsp");
        }
        localStorage.setItem("cmsp",attrStr);
    }
    if(isGPS && !localStorage.getItem("LatLong")){
        getCurrentPosition();
    }
}
var channel = 20;

var geol;
function getCurrentPosition(){
        try {
            if (typeof(navigator.geolocation) == 'undefined') {  
                geol = google.gears.factory.create('beta.geolocation');  
            } else {  
                geol = navigator.geolocation;  
            }  
        } catch (error) {  
            //alert(error.message);  
        }  
          
        if (geol) {  
            geol.getCurrentPosition(function(position) {  
          
        var nowLatitude = position.coords.latitude;  
        var nowLongitude = position.coords.longitude;  
        
        
        localStorage.setItem("LatLong",nowLatitude + ',' + nowLongitude);
                
    }, function(error) {  
        switch(error.code){  
        case error.TIMEOUT :  
            //alert("连接超时，请重试");  
            break;  
        case error.PERMISSION_DENIED :  
            //alert("您拒绝了使用位置共享服务，查询已取消");  
            break;  
        case error.POSITION_UNAVAILABLE :   
            //alert("非常抱歉，我们暂时无法通过浏览器获取您的位置信息");  
            break;  
        }  
    }, {timeout:10000});    //设置十秒超时  
        }
}

